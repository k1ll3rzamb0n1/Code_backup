DELETE FROM odetails;
DELETE FROM orders;
DELETE FROM cart;
DELETE FROM creditcards;
DELETE FROM members;
DELETE FROM books;

source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/bookssmall2.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/authors.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/members.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/creditcards.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/orders.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/odetails.sql;
source c:/Users/Ryan/Desktop/DBMS/Project/BookStore/cart.sql;
