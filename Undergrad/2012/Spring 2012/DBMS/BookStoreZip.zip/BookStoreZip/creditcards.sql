INSERT INTO creditcards VALUE ('rfeyn2', 1, 'Visa', '1234567890123456', '123 yay ln', 'stockon', 'ca', '95211');
INSERT INTO creditcards VALUE ('rfeyn2', 2, 'Master', '1234567890987654', '123 yay ln', 'stockon', 'ca', '95211');
INSERT INTO creditcards VALUE ('rfeyn3', 1, 'Master', '0123456789123232', '123 yay ln', 'stockon', 'ca', '95211');
INSERT INTO creditcards VALUE ('rprod1', 1, 'Visa', '9889889889889889', '123 yay ln', 'stockon', 'ca', '95211');
INSERT INTO creditcards VALUE ('rprod2', 1, 'Visa', '9889889889889889', '123 yay ln', 'stockon', 'ca', '95211');
